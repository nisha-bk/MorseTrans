import UIKit
import MessageUI

final class SettingsViewController: UIViewController, MFMailComposeViewControllerDelegate {

    private let tableView = UITableView(frame: .zero, style: .insetGrouped)

    private enum Section: Int, CaseIterable {
        case preferences
        case quiz
        case reset
        case about
    }

    private var isSoundOn: Bool {
        get { UserDefaults.standard.object(forKey: "isSoundOn") as? Bool ?? true }
        set { UserDefaults.standard.set(newValue, forKey: "isSoundOn") }
    }

    private var isVibrationOn: Bool {
        get { UserDefaults.standard.object(forKey: "isVibrationOn") as? Bool ?? true }
        set { UserDefaults.standard.set(newValue, forKey: "isVibrationOn") }
    }

    private var difficulty: String {
        get { UserDefaults.standard.string(forKey: "quizDifficulty") ?? "Medium" }
        set { UserDefaults.standard.set(newValue, forKey: "quizDifficulty") }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Settings"
        AppTheme.applyGradient(to: view)
        setupTableView()
    }

    private func setupTableView() {
        tableView.backgroundColor = .clear
        tableView.delegate = self
        tableView.dataSource = self
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tableView.estimatedRowHeight = 60
        tableView.rowHeight = UITableView.automaticDimension

        view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }

    @objc private func soundToggled(_ sender: UISwitch) { isSoundOn = sender.isOn }
    @objc private func vibrationToggled(_ sender: UISwitch) { isVibrationOn = sender.isOn }

    private func showDifficultyOptions() {
        let alert = UIAlertController(title: "Quiz Difficulty", message: "Select difficulty level", preferredStyle: .actionSheet)
        ["Easy", "Medium", "Hard"].forEach { level in
            alert.addAction(UIAlertAction(title: level, style: .default, handler: { _ in
                self.difficulty = level
                self.tableView.reloadSections([Section.quiz.rawValue], with: .automatic)
            }))
        }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    private func confirmReset() {
        let alert = UIAlertController(title: "Reset Progress", message: "Are you sure you want to reset quiz progress?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Reset", style: .destructive, handler: { _ in
            UserDefaults.standard.removeObject(forKey: "quizProgress")
            print("Progress reset")
        }))
        present(alert, animated: true)
    }

    private func sendFeedback() {
        guard MFMailComposeViewController.canSendMail() else {
            let alert = UIAlertController(title: "Mail Not Configured", message: "Please set up an email account on this device.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
            return
        }

        let mailVC = MFMailComposeViewController()
        mailVC.mailComposeDelegate = self
        mailVC.setToRecipients(["support@example.com"])
        mailVC.setSubject("MorseTrans Feedback")
        present(mailVC, animated: true)
    }

    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true)
    }
}

extension SettingsViewController: UITableViewDelegate, UITableViewDataSource {

    func numberOfSections(in tableView: UITableView) -> Int { Section.allCases.count }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch Section(rawValue: section)! {
        case .preferences: return 2
        case .quiz: return 1
        case .reset: return 1
        case .about: return 2
        }
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch Section(rawValue: section)! {
        case .preferences: return "Preferences"
        case .quiz: return "Quiz Settings"
        case .reset: return " "
        case .about: return "About"
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = UITableViewCell(style: .value1, reuseIdentifier: "cell")
        cell.selectionStyle = .none
        cell.layer.cornerRadius = 12
        cell.layer.masksToBounds = true
        cell.backgroundColor = UIColor.white.withAlphaComponent(0.2)
        cell.textLabel?.textColor = .black
        cell.detailTextLabel?.textColor = .darkGray

        switch Section(rawValue: indexPath.section)! {
        case .preferences:
            if indexPath.row == 0 {
                cell.textLabel?.text = "Sound"
                cell.imageView?.image = UIImage(systemName: "speaker.wave.2.fill")?.withTintColor(.systemBlue, renderingMode: .alwaysOriginal)
                let toggle = UISwitch()
                toggle.isOn = isSoundOn
                toggle.addTarget(self, action: #selector(soundToggled(_:)), for: .valueChanged)
                cell.accessoryView = toggle
            } else {
                cell.textLabel?.text = "Vibration"
                cell.imageView?.image = UIImage(systemName: "waveform.path")?.withTintColor(.systemRed, renderingMode: .alwaysOriginal)
                let toggle = UISwitch()
                toggle.isOn = isVibrationOn
                toggle.addTarget(self, action: #selector(vibrationToggled(_:)), for: .valueChanged)
                cell.accessoryView = toggle
            }

        case .quiz:
            cell.textLabel?.text = "Difficulty"
            cell.detailTextLabel?.text = difficulty
            cell.accessoryType = .disclosureIndicator
            cell.imageView?.image = UIImage(systemName: "gamecontroller.fill")?.withTintColor(.systemGreen, renderingMode: .alwaysOriginal)

        case .reset:
            cell.textLabel?.text = "Reset Progress"
            cell.textLabel?.textColor = .systemRed
            cell.textLabel?.textAlignment = .center
            cell.imageView?.image = UIImage(systemName: "trash.fill")?.withTintColor(.systemRed, renderingMode: .alwaysOriginal)

        case .about:
            if indexPath.row == 0 {
                cell.textLabel?.text = "App Version"
                let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0"
                let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1"
                cell.detailTextLabel?.text = "\(version) (\(build))"
                cell.accessoryType = .none
                cell.imageView?.image = UIImage(systemName: "info.circle")?.withTintColor(.systemGray, renderingMode: .alwaysOriginal)
            } else {
                cell.textLabel?.text = "Send Feedback"
                cell.textLabel?.textColor = .systemBlue
                cell.textLabel?.textAlignment = .left
                cell.accessoryType = .disclosureIndicator
                cell.imageView?.image = UIImage(systemName: "envelope.fill")?.withTintColor(.systemBlue, renderingMode: .alwaysOriginal)
            }
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch Section(rawValue: indexPath.section)! {
        case .quiz: showDifficultyOptions()
        case .reset: confirmReset()
        case .about:
            if indexPath.row == 1 { sendFeedback() }
        default: break
        }
    }
}
