//
//  LibraryViewController.swift
//  MorseTrans
//

import UIKit

class LibraryViewController: UIViewController {
    
    private let tableView = UITableView(frame: .zero, style: .insetGrouped)
    
    private var savedItems: [String] = []
    
    private let storageKey = "SavedMorseItems"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        AppTheme.applyGradient(to: view)
        title = "Library"
        
        loadItems()
        setupTable()
        setupAddButton()
    }
    
    // MARK: - Setup
    private func setupTable() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = .clear
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        
        view.addSubview(tableView)
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    private func setupAddButton() {
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .add,
            target: self,
            action: #selector(addNewItem)
        )
    }

    private func saveItems() {
        UserDefaults.standard.set(savedItems, forKey: storageKey)
    }
    
    private func loadItems() {
        savedItems = UserDefaults.standard.stringArray(forKey: storageKey) ?? []
    }

    @objc private func addNewItem() {
        let alert = UIAlertController(title: "Add Entry", message: "Enter text and Morse code", preferredStyle: .alert)
        alert.addTextField { $0.placeholder = "Enter Text" }
        alert.addTextField { $0.placeholder = "Enter Morse Code" }
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Save", style: .default, handler: { _ in
            let text = alert.textFields?[0].text ?? ""
            let morse = alert.textFields?[1].text ?? ""
            guard !text.isEmpty, !morse.isEmpty else { return }
            
            let entry = "\(text.uppercased()) → \(morse)"
            self.savedItems.append(entry)
            self.saveItems()
            self.tableView.reloadData()
        }))
        
        present(alert, animated: true)
    }
}

extension LibraryViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return savedItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = savedItems[indexPath.row]
        cell.textLabel?.textColor = .white
        cell.backgroundColor = UIColor.black.withAlphaComponent(0.25)
        cell.layer.cornerRadius = 10
        cell.clipsToBounds = true
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let item = savedItems[indexPath.row]
        let alert = UIAlertController(title: "Selected", message: item, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle,
                   forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            savedItems.remove(at: indexPath.row)
            saveItems()
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
}
