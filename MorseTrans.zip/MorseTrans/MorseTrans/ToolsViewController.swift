import UIKit

class ToolsViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        AppTheme.applyGradient(to: view)
        setupUI()
    }
    
    private func setupUI() {
        title = "Tools"
  
        let quizBtn = makeRoundedButton(title: "Morse Quiz", action: #selector(openQuiz))
        let practiceBtn = makeRoundedButton(title: "Practice Mode", action: #selector(openPractice))
        let settingsBtn = makeRoundedButton(title: "Settings", action: #selector(openSettings))
  
        let stack = UIStackView(arrangedSubviews: [quizBtn, practiceBtn, settingsBtn])
        stack.axis = .vertical
        stack.spacing = 25
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.alignment = .center
        view.addSubview(stack)
        
        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            quizBtn.widthAnchor.constraint(equalToConstant: 250),
            practiceBtn.widthAnchor.constraint(equalToConstant: 250),
            settingsBtn.widthAnchor.constraint(equalToConstant: 250),
            quizBtn.heightAnchor.constraint(equalToConstant: 60),
            practiceBtn.heightAnchor.constraint(equalToConstant: 60),
            settingsBtn.heightAnchor.constraint(equalToConstant: 60),
        ])
    }

    private func makeRoundedButton(title: String, action: Selector) -> UIButton {
        let button = UIButton(type: .system)
        button.setTitle(title, for: .normal)
        button.setTitleColor(.white, for: .normal)
        let gradient = CAGradientLayer()
        gradient.colors = [
            UIColor.systemPink.withAlphaComponent(0.9).cgColor,
            UIColor.systemPurple.withAlphaComponent(0.9).cgColor
        ]
        gradient.startPoint = CGPoint(x: 0, y: 0)
        gradient.endPoint = CGPoint(x: 1, y: 1)
        gradient.frame = CGRect(x: 0, y: 0, width: 250, height: 60)
        gradient.cornerRadius = 30
        
        button.layer.insertSublayer(gradient, at: 0)
        button.layer.cornerRadius = 30
        button.layer.masksToBounds = true

        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = 0.25
        button.layer.shadowRadius = 8
        button.layer.shadowOffset = CGSize(width: 0, height: 4)
        
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        button.translatesAutoresizingMaskIntoConstraints = false

        button.addTarget(self, action: action, for: .touchUpInside)

        button.addTarget(self, action: #selector(buttonPressed(_:)), for: [.touchDown, .touchDragEnter])
        button.addTarget(self, action: #selector(buttonReleased(_:)), for: [.touchUpInside, .touchDragExit, .touchCancel])
        return button
    }

    @objc private func buttonPressed(_ sender: UIButton) {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        UIView.animate(withDuration: 0.15) {
            sender.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
        }
    }
    
    @objc private func buttonReleased(_ sender: UIButton) {
        UIView.animate(withDuration: 0.15) {
            sender.transform = .identity
        }
    }

    @objc private func openQuiz() {
        let vc = QuizViewController()
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc private func openPractice() {
        let vc = PracticeViewController()
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc private func openSettings() {
        let vc = SettingsViewController()
        navigationController?.pushViewController(vc, animated: true)
    }
}
