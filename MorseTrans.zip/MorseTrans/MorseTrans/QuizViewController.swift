import UIKit

class QuizViewController: UIViewController {
    
    private let morseDict: [String: String] = [
        "A": ".-", "B": "-...", "C": "-.-.", "D": "-..", "E": ".",
        "F": "..-.", "G": "--.", "H": "....", "I": "..", "J": ".---",
        "K": "-.-", "L": ".-..", "M": "--", "N": "-.", "O": "---",
        "P": ".--.", "Q": "--.-", "R": ".-.", "S": "...", "T": "-",
        "U": "..-", "V": "...-", "W": ".--", "X": "-..-", "Y": "-.--",
        "Z": "--.."
    ]
    
    private var currentQuestion: (letter: String, morse: String)?
    private var score = 0
    private var total = 0
    
    private let questionLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.textColor = .white
        label.textAlignment = .center
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let scoreLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        label.textColor = .black
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private var answerButtons: [UIButton] = []
    private let nextButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("Next Question", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.backgroundColor = UIColor.systemBlue.withAlphaComponent(0.7)
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        btn.layer.cornerRadius = 20
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.isHidden = true
        return btn
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        AppTheme.applyGradient(to: view)
        setupUI()
        loadQuestion()
    }
    
    private func setupUI() {
        title = "Morse Quiz"
        
        let answersStack = UIStackView()
        answersStack.axis = .vertical
        answersStack.spacing = 15
        answersStack.alignment = .center
        answersStack.translatesAutoresizingMaskIntoConstraints = false
  
        for _ in 0..<4 {
            let btn = makeAnswerButton()
            answersStack.addArrangedSubview(btn)
            answerButtons.append(btn)
            
            NSLayoutConstraint.activate([
                btn.widthAnchor.constraint(equalToConstant: 220),
                btn.heightAnchor.constraint(equalToConstant: 50)
            ])
        }
        
        nextButton.addTarget(self, action: #selector(nextQuestion), for: .touchUpInside)
        
        view.addSubview(questionLabel)
        view.addSubview(scoreLabel)
        view.addSubview(answersStack)
        view.addSubview(nextButton)
        
        NSLayoutConstraint.activate([
            scoreLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            scoreLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            questionLabel.topAnchor.constraint(equalTo: scoreLabel.bottomAnchor, constant: 30),
            questionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            questionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            answersStack.topAnchor.constraint(equalTo: questionLabel.bottomAnchor, constant: 40),
            answersStack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            nextButton.topAnchor.constraint(equalTo: answersStack.bottomAnchor, constant: 30),
            nextButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            nextButton.widthAnchor.constraint(equalToConstant: 200),
            nextButton.heightAnchor.constraint(equalToConstant: 45)
        ])
    }
    
    private func makeAnswerButton() -> UIButton {
        let button = UIButton(type: .system)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        button.layer.cornerRadius = 25
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(answerTapped(_:)), for: .touchUpInside)
        return button
    }
    
    private func loadQuestion() {
        guard let randomLetter = morseDict.keys.randomElement(),
              let correctMorse = morseDict[randomLetter] else { return }
        
        currentQuestion = (randomLetter, correctMorse)
        total += 1
        updateScoreLabel()
        
        questionLabel.text = "What is Morse code for \(randomLetter)?"
        
        // Generate wrong options
        var options = [correctMorse]
        while options.count < 4 {
            if let randomWrong = morseDict.values.randomElement(), !options.contains(randomWrong) {
                options.append(randomWrong)
            }
        }
        
        options.shuffle()
        
        for (i, btn) in answerButtons.enumerated() {
            btn.setTitle(options[i], for: .normal)
            btn.backgroundColor = UIColor.black.withAlphaComponent(0.3)
            btn.isEnabled = true
        }
        
        nextButton.isHidden = true
    }
    
    @objc private func answerTapped(_ sender: UIButton) {
        guard let answer = sender.title(for: .normal),
              let correctAnswer = currentQuestion?.morse else { return }
        
        if answer == correctAnswer {
            sender.backgroundColor = UIColor.systemGreen.withAlphaComponent(0.7)
            score += 1
        } else {
            sender.backgroundColor = UIColor.systemRed.withAlphaComponent(0.7)
   
            if let correctBtn = answerButtons.first(where: { $0.title(for: .normal) == correctAnswer }) {
                correctBtn.backgroundColor = UIColor.systemGreen.withAlphaComponent(0.7)
            }
        }
    
        for btn in answerButtons { btn.isEnabled = false }
        
        updateScoreLabel()
        nextButton.isHidden = false
    }
    
    @objc private func nextQuestion() {
        loadQuestion()
    }
    
    private func updateScoreLabel() {
        scoreLabel.text = "Score: \(score)/\(total - 1)"
    }
}
