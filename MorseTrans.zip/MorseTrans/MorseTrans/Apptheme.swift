import UIKit

enum AppTheme {
    static func applyGradient(to view: UIView) {
        view.layer.sublayers?.removeAll(where: { $0.name == "AppThemeGradient" })
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.name = "AppThemeGradient"

        gradientLayer.colors = [
            UIColor(red: 1.00, green: 0.85, blue: 0.90, alpha: 1.0).cgColor,
            UIColor(red: 0.95, green: 0.70, blue: 0.95, alpha: 1.0).cgColor,
            UIColor(red: 0.80, green: 0.85, blue: 1.00, alpha: 1.0).cgColor
        ]
        
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds
        
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
}
