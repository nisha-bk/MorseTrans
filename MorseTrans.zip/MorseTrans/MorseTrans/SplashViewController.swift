import UIKit

final class SplashViewController: UIViewController {

    private let logoImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage(systemName: "dot.radiowaves.left.and.right"))
        imageView.tintColor = .purple
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.alpha = 0
        return imageView
    }()

    private let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "MorseTrans"
        label.font = UIFont.systemFont(ofSize: 30, weight: .bold)
        label.textColor = .purple
        label.translatesAutoresizingMaskIntoConstraints = false
        label.alpha = 0
        return label
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        AppTheme.applyGradient(to: view)

        setupUI()
        animateSplash()
    }

    private func setupUI() {
        view.addSubview(logoImageView)
        view.addSubview(titleLabel)

        NSLayoutConstraint.activate([
            logoImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            logoImageView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -40),
            logoImageView.widthAnchor.constraint(equalToConstant: 150),
            logoImageView.heightAnchor.constraint(equalToConstant: 150),

            titleLabel.topAnchor.constraint(equalTo: logoImageView.bottomAnchor, constant: 20),
            titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }

    private func animateSplash() {
    
        UIView.animate(withDuration: 1.0, delay: 0.2, options: .curveEaseIn, animations: {
            self.logoImageView.alpha = 1
        }, completion: { _ in
    
            UIView.animate(withDuration: 0.5, animations: {
                self.logoImageView.transform = CGAffineTransform(scaleX: 2.2, y: 2.2)
            }, completion: { _ in
                UIView.animate(withDuration: 0.3) {
                    self.logoImageView.transform = CGAffineTransform.identity
                    self.titleLabel.alpha = 1
                }
            })
        })

        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
            let mainTab = MainTabBarController()
            mainTab.modalTransitionStyle = .crossDissolve
            mainTab.modalPresentationStyle = .fullScreen
            self.present(mainTab, animated: true)
        }
    }
}
