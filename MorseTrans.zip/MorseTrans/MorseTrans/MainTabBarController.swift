

import UIKit

final class MainTabBarController: UITabBarController {
    override func viewDidLoad() {
        super.viewDidLoad()
        AppTheme.applyGradient(to: view)

        let learn = nav(LearnViewController(), title: "Learn", systemImage: "book")
        let history = nav(MorseHistoryViewController(), title: "History", systemImage: "clock.arrow.circlepath")
        let tools = nav(ToolsViewController(), title: "Tools", systemImage: "wrench.and.screwdriver")
        let library = nav(LibraryViewController(), title: "Library", systemImage: "tray.full")
        viewControllers = [learn, tools, library, history]
    }

    private func nav(_ root: UIViewController, title: String, systemImage: String) -> UINavigationController {
        root.title = title
        let nav = UINavigationController(rootViewController: root)
        nav.tabBarItem = UITabBarItem(title: title, image: UIImage(systemName: systemImage), selectedImage: nil)
        return nav
    }

}
