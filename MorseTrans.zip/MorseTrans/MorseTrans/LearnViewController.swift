import UIKit
import AudioToolbox

class LearnViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    private var collectionView: UICollectionView!
    
    private let morseDict: [String: String] = [
        "A": ".-", "B": "-...", "C": "-.-.", "D": "-..", "E": ".", "F": "..-.",
        "G": "--.", "H": "....", "I": "..", "J": ".---", "K": "-.-", "L": ".-..",
        "M": "--", "N": "-.", "O": "---", "P": ".--.", "Q": "--.-", "R": ".-.",
        "S": "...", "T": "-", "U": "..-", "V": "...-", "W": ".--", "X": "-..-",
        "Y": "-.--", "Z": "--..",
        "0": "-----", "1": ".----", "2": "..---", "3": "...--", "4": "....-",
        "5": ".....", "6": "-....", "7": "--...", "8": "---..", "9": "----.",
        ".": ".-.-.-", ",": "--..--", "?": "..--..", "!": "-.-.--",
        "/": "-..-.", "@": ".--.-.", "-": "-....-", ":": "---...",
        ";": "-.-.-.", "=": "-...-", "+": ".-.-.", "_": "..--.-",
        "\"": ".-..-.", "$": "...-..-", "&": ".-...", "'": ".----."
    ]
    
    private var letters: [String] = []

    private let headerImageView = UIImageView()
    private let descriptionLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Learn Morse"
        AppTheme.applyGradient(to: view)
        letters = morseDict.keys.sorted()
        setupHeader()
        setupCollectionView()
    }
    
    private func setupHeader() {
        headerImageView.image = UIImage(systemName: "dot.radiowaves.left.and.right")
        headerImageView.tintColor = .purple
        headerImageView.contentMode = .scaleAspectFit
        headerImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headerImageView)
        
        descriptionLabel.text = "Morse code is a system for sending messages using short signals (dots •) and long signals (dashes –). Each letter, number, and some punctuation have a unique pattern. Originally used for telegraphs and radio communication, it’s still useful for emergency signaling, learning communication basics, and understanding historic technologies. Tap a letter to hear its Morse sound and practice memorizing the patterns."
        descriptionLabel.font = UIFont.systemFont(ofSize: 14)
        descriptionLabel.textColor = .purple
        descriptionLabel.numberOfLines = 0
        descriptionLabel.textAlignment = .center
        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(descriptionLabel)
        
        NSLayoutConstraint.activate([
            headerImageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 8),
            headerImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            headerImageView.heightAnchor.constraint(equalToConstant: 60),
            headerImageView.widthAnchor.constraint(equalToConstant: 60),
            
            descriptionLabel.topAnchor.constraint(equalTo: headerImageView.bottomAnchor, constant: 6),
            descriptionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            descriptionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
        ])
    }
    
    private func setupCollectionView() {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = 8
        layout.minimumInteritemSpacing = 8
        
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.backgroundColor = .clear
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(MorseCell.self, forCellWithReuseIdentifier: "MorseCell")
        view.addSubview(collectionView)
        
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: 8),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 12),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -12),
            collectionView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -8)
        ])
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        letters.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MorseCell", for: indexPath) as? MorseCell else {
            return UICollectionViewCell()
        }
        let letter = letters[indexPath.item]
        cell.configure(letter: letter, morse: morseDict[letter] ?? "")
        return cell
    }
 
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let letter = letters[indexPath.item]
        let morse = morseDict[letter] ?? ""
        playMorse(morse)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.bounds.width
        let height: CGFloat = 50
        return CGSize(width: width, height: height)
    }

    private func playMorse(_ morse: String) {
        let dotDuration: TimeInterval = 0.15
        let dashDuration: TimeInterval = dotDuration * 3
        let gapDuration: TimeInterval = dotDuration
        
        var delay: TimeInterval = 0
        for char in morse {
            switch char {
            case ".":
                playBeep(after: delay, duration: dotDuration)
                delay += dotDuration + gapDuration
            case "-":
                playBeep(after: delay, duration: dashDuration)
                delay += dashDuration + gapDuration
            default:
                delay += gapDuration
            }
        }
    }
    
    private func playBeep(after delay: TimeInterval, duration: TimeInterval) {
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
            AudioServicesPlaySystemSound(1104)
        }
    }
}

class MorseCell: UICollectionViewCell {
    
    private let letterLabel = UILabel()
    private let morseLabel = UILabel()
    private let cardView = UIView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) { fatalError() }
    
    func configure(letter: String, morse: String) {
        letterLabel.text = letter
        morseLabel.text = morse
    }
    
    private func setupUI() {
        contentView.backgroundColor = .clear
        
        cardView.backgroundColor = UIColor.systemGray5
        cardView.layer.cornerRadius = 12
        cardView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(cardView)
        
        letterLabel.font = UIFont.boldSystemFont(ofSize: 18)
        letterLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(letterLabel)
        
        morseLabel.font = UIFont.monospacedSystemFont(ofSize: 16, weight: .medium)
        morseLabel.textColor = .systemGray
        morseLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(morseLabel)
        
        NSLayoutConstraint.activate([
            cardView.topAnchor.constraint(equalTo: contentView.topAnchor),
            cardView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            cardView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            cardView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            
            letterLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 12),
            letterLabel.centerYAnchor.constraint(equalTo: cardView.centerYAnchor),
            
            morseLabel.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -12),
            morseLabel.centerYAnchor.constraint(equalTo: cardView.centerYAnchor)
        ])
    }
}
