
import UIKit
import AVFoundation

class PracticeViewController: UIViewController {
    
    let segmentControl: UISegmentedControl = {
        let sc = UISegmentedControl(items: ["TEXT → MORSE", "MORSE → TEXT"])
        sc.selectedSegmentIndex = 0
        sc.selectedSegmentTintColor = UIColor.purple.withAlphaComponent(0.2)
        sc.backgroundColor = UIColor.systemGray6
        return sc
    }()
    
    let inputTV: UITextView = {
        let tv = UITextView()
        tv.layer.cornerRadius = 10
        tv.layer.borderWidth = 1
        tv.layer.borderColor = UIColor.systemGray2.cgColor
        tv.backgroundColor = UIColor.systemTeal.withAlphaComponent(0.1)
        tv.font = UIFont.systemFont(ofSize: 16)
        return tv
    }()
    
    let outputTV: UITextView = {
        let tv = UITextView()
        tv.layer.cornerRadius = 10
        tv.layer.borderWidth = 1
        tv.layer.borderColor = UIColor.systemGray2.cgColor
        tv.backgroundColor = UIColor.systemTeal.withAlphaComponent(0.1)
        tv.font = UIFont.systemFont(ofSize: 16)
        tv.isEditable = false
        return tv
    }()
    
    let convertBtn = PracticeViewController.makeRoundedButton(title: "Convert", systemImage: "arrow.left.arrow.right.circle.fill")
    let copyBtn = PracticeViewController.makeRoundedButton(title: "Copy", systemImage: "doc.on.doc.fill")
    let playBtn = PracticeViewController.makeRoundedButton(title: "Play", systemImage: "play.circle.fill")
    let clearBtn = PracticeViewController.makeRoundedButton(title: "Clear", systemImage: "trash.fill", color: .systemGray)

    let morseDict: [Character: String] = [
        "A": ".-", "B": "-...", "C": "-.-.", "D": "-..",
        "E": ".", "F": "..-.", "G": "--.", "H": "....",
        "I": "..", "J": ".---", "K": "-.-", "L": ".-..",
        "M": "--", "N": "-.", "O": "---", "P": ".--.",
        "Q": "--.-", "R": ".-.", "S": "...", "T": "-",
        "U": "..-", "V": "...-", "W": ".--", "X": "-..-",
        "Y": "-.--", "Z": "--..",
        "0": "-----", "1": ".----", "2": "..---", "3": "...--",
        "4": "....-", "5": ".....", "6": "-....", "7": "--...",
        "8": "---..", "9": "----.",
        ".": ".-.-.-", ",": "--..--", "?": "..--..",
        "!": "-.-.--", "/": "-..-.", "(": "-.--.", ")": "-.--.-",
        "&": ".-...", ":": "---...", ";": "-.-.-.", "=": "-...-",
        "+": ".-.-.", "-": "-....-", "_": "..--.-",
        "\"": ".-..-.", "$": "...-..-", "@": ".--.-.",
        " ": "/"
    ]
    
    lazy var reverseMorseDict: [String: Character] = {
        var dict = [String: Character]()
        for (key, value) in morseDict {
            dict[value] = key
        }
        return dict
    }()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Practice Mode"
        AppTheme.applyGradient(to: view)
        setupUI()
   
        convertBtn.addTarget(self, action: #selector(convertTapped), for: .touchUpInside)
        clearBtn.addTarget(self, action: #selector(clearTapped), for: .touchUpInside)
        copyBtn.addTarget(self, action: #selector(copyTapped), for: .touchUpInside)
        playBtn.addTarget(self, action: #selector(playTapped), for: .touchUpInside)
    }
   
    private func setupUI() {
        view.addSubview(segmentControl)
        view.addSubview(inputTV)
        view.addSubview(convertBtn)
        view.addSubview(outputTV)
 
        segmentControl.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            segmentControl.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            segmentControl.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            segmentControl.widthAnchor.constraint(equalToConstant: 240)
        ])
       
        inputTV.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            inputTV.topAnchor.constraint(equalTo: segmentControl.bottomAnchor, constant: 20),
            inputTV.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            inputTV.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            inputTV.heightAnchor.constraint(equalToConstant: 120)
        ])
  
        convertBtn.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            convertBtn.topAnchor.constraint(equalTo: inputTV.bottomAnchor, constant: 20),
            convertBtn.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            convertBtn.widthAnchor.constraint(equalToConstant: 140),
            convertBtn.heightAnchor.constraint(equalToConstant: 44)
        ])

        outputTV.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            outputTV.topAnchor.constraint(equalTo: convertBtn.bottomAnchor, constant: 20),
            outputTV.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            outputTV.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            outputTV.heightAnchor.constraint(equalToConstant: 120)
        ])
 
        let bottomStack = UIStackView(arrangedSubviews: [copyBtn, playBtn, clearBtn])
        bottomStack.axis = .horizontal
        bottomStack.spacing = 10
        bottomStack.distribution = .fillEqually
        bottomStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bottomStack)
        
        NSLayoutConstraint.activate([
            bottomStack.topAnchor.constraint(equalTo: outputTV.bottomAnchor, constant: 20),
            bottomStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            bottomStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            bottomStack.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    static func makeRoundedButton(title: String, systemImage: String, color: UIColor = .clear) -> UIButton {
        let btn = UIButton(type: .system)
        btn.setTitle(" " + title, for: .normal)
        btn.setTitleColor(.black, for: .normal)
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        btn.setImage(UIImage(systemName: systemImage), for: .normal)
        btn.tintColor = .black
        btn.backgroundColor = UIColor.black.withAlphaComponent(0.1)
        btn.layer.cornerRadius = 10
        btn.clipsToBounds = true
        return btn
    }

    @objc func convertTapped() {
        let input = inputTV.text ?? ""
        if segmentControl.selectedSegmentIndex == 0 {
            outputTV.text = convertTextToMorse(input)
        } else {
            outputTV.text = convertMorseToText(input)
        }
    }
    
    @objc func clearTapped() {
        inputTV.text = ""
        outputTV.text = ""
    }
    
    @objc func copyTapped() {
        UIPasteboard.general.string = outputTV.text
    }
    
    @objc func playTapped() {
        playMorse(outputTV.text)
    }

    func convertTextToMorse(_ input: String) -> String {
        input.uppercased()
            .compactMap { morseDict[$0] }
            .joined(separator: " ")
    }
    
    func convertMorseToText(_ input: String) -> String {
        input.components(separatedBy: " ")
            .compactMap { reverseMorseDict[$0] }
            .map { String($0) }
            .joined()
    }
    
    func playMorse(_ morse: String?) {
        guard let morse = morse else { return }
        
        DispatchQueue.global().async {
            for char in morse {
                if char == "." {
                    AudioServicesPlaySystemSound(1104)
                    usleep(200_000)
                } else if char == "-" {
                    AudioServicesPlaySystemSound(1104)
                    usleep(500_000)
                } else if char == " " || char == "/" {
                    usleep(400_000)
                }
            }
        }
    }
}
