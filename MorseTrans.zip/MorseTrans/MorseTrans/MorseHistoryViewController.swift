import UIKit
import AudioToolbox

final class MorseHistoryViewController: UIViewController {

    struct HistoryItem {
        let title: String
        let description: String
        let imageName: String?
        let morseCode: String?
    }

    private let tableView = UITableView(frame: .zero, style: .plain)

    private let historyItems: [HistoryItem] = [
         HistoryItem(title: "1837 – Telegraph Invented",
                     description: "Samuel Morse and Alfred Vail developed the first practical telegraph system and the Morse code alphabet.",
                     imageName: "telegraph",
                     morseCode: nil),
         HistoryItem(title: "1844 – First Official Message",
                     description: "The first official message was 'What hath God wrought?' sent from Washington, D.C., to Baltimore.",
                     imageName: "message",
                     morseCode: nil),
         HistoryItem(title: "1851 – Telegraph Lines",
                     description: "Telegraph lines expanded rapidly, connecting cities and enabling instant communication.",
                     imageName: "lines",
                     morseCode: nil),
         HistoryItem(title: "1905 – Morse Standardized",
                     description: "A standardized version of Morse code was adopted internationally for telegraphy.",
                     imageName: "standard",
                     morseCode: nil),
         HistoryItem(title: "1906 – Wireless Telegraphy",
                     description: "Morse code was used in early radio transmissions, enabling messages without physical wires.",
                     imageName: "radio",
                     morseCode: nil),
         HistoryItem(title: "1912 – Titanic Distress Call",
                     description: "The Titanic sent the SOS signal (... --- ...) after hitting an iceberg.",
                     imageName: "sos",
                     morseCode: "... --- ..."),
         HistoryItem(title: "WWI & WWII Military Use",
                     description: "Morse code was critical for military communication, including secret messages and ship-to-ship communication.",
                     imageName: "military",
                     morseCode: nil),
         HistoryItem(title: "Amateur Radio",
                     description: "Morse code remains popular among ham radio enthusiasts worldwide.",
                     imageName: "ham_radio",
                     morseCode: nil),
         HistoryItem(title: "Aviation and Navigation",
                     description: "Pilots and navigators still use Morse signals to identify navigational beacons (VORs).",
                     imageName: "aviation",
                     morseCode: nil),
         HistoryItem(title: "Emergency Signaling",
                     description: "SOS and other Morse sequences can be used with flashlights, taps, or whistles in emergencies.",
                     imageName: "emergency",
                     morseCode: "... --- ..."),
         HistoryItem(title: "Cultural References",
                     description: "Morse code appears in movies, books, and games as a classic communication tool.",
                     imageName: "culture",
                     morseCode: nil),
         HistoryItem(title: "Modern Learning Tool",
                     description: "Morse code is taught to improve cognitive skills, memory, and pattern recognition.",
                     imageName: "learning",
                     morseCode: nil)
     ]
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Morse History"
        AppTheme.applyGradient(to: view)
        setupTableView()
    }

    private func setupTableView() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = .clear
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.register(MorseHistoryCell.self, forCellReuseIdentifier: "MorseHistoryCell")
        view.addSubview(tableView)

        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 8),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 12),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -12),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -8)
        ])
    }

    private func playMorse(_ morse: String) {
        let dot: TimeInterval = 0.15
        let dash: TimeInterval = dot * 3
        let gap: TimeInterval = dot
        var delay: TimeInterval = 0
        for char in morse {
            switch char {
            case ".":
                DispatchQueue.main.asyncAfter(deadline: .now() + delay) { AudioServicesPlaySystemSound(1104) }
                delay += dot + gap
            case "-":
                DispatchQueue.main.asyncAfter(deadline: .now() + delay) { AudioServicesPlaySystemSound(1104) }
                delay += dash + gap
            default:
                delay += gap
            }
        }
    }
}

extension MorseHistoryViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        historyItems.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        guard let cell = tableView.dequeueReusableCell(withIdentifier: "MorseHistoryCell", for: indexPath) as? MorseHistoryCell else {
            return UITableViewCell()
        }

        let item = historyItems[indexPath.row]
        cell.configure(with: item)
        cell.playButtonAction = { [weak self] in
            if let morse = item.morseCode {
                self?.playMorse(morse)
            }
        }

        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

final class MorseHistoryCell: UITableViewCell {

    private let cardView = UIView()
    private let itemImageView = UIImageView()
    private let titleLabel = UILabel()
    private let descriptionLabel = UILabel()
    private let playButton = UIButton(type: .system)

    var playButtonAction: (() -> Void)?

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }

    required init?(coder: NSCoder) { fatalError() }

    private func setupUI() {
        selectionStyle = .none
        backgroundColor = .clear

        cardView.backgroundColor = UIColor.black.withAlphaComponent(0.2)
        cardView.layer.cornerRadius = 16
        cardView.layer.shadowColor = UIColor.black.cgColor
        cardView.layer.shadowOpacity = 0.1
        cardView.layer.shadowOffset = CGSize(width: 0, height: 4)
        cardView.layer.shadowRadius = 8
        cardView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(cardView)

        itemImageView.contentMode = .scaleAspectFit
        itemImageView.layer.cornerRadius = 8
        itemImageView.clipsToBounds = true
        itemImageView.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(itemImageView)

        titleLabel.font = UIFont.boldSystemFont(ofSize: 18)
        titleLabel.textColor = .white
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(titleLabel)

        descriptionLabel.font = UIFont.systemFont(ofSize: 14)
        descriptionLabel.textColor = .white
        descriptionLabel.numberOfLines = 0
        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(descriptionLabel)

        playButton.setImage(UIImage(systemName: "play.circle.fill"), for: .normal)
        playButton.tintColor = .systemYellow
        playButton.translatesAutoresizingMaskIntoConstraints = false
        playButton.addTarget(self, action: #selector(playTapped), for: .touchUpInside)
        cardView.addSubview(playButton)

        NSLayoutConstraint.activate([
            cardView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            cardView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8),
            cardView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            cardView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            itemImageView.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 12),
            itemImageView.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 12),
            itemImageView.heightAnchor.constraint(equalToConstant: 50),
            itemImageView.widthAnchor.constraint(equalToConstant: 50),

            titleLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 12),
            titleLabel.leadingAnchor.constraint(equalTo: itemImageView.trailingAnchor, constant: 12),
            titleLabel.trailingAnchor.constraint(equalTo: playButton.leadingAnchor, constant: -8),

            descriptionLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 6),
            descriptionLabel.leadingAnchor.constraint(equalTo: itemImageView.trailingAnchor, constant: 12),
            descriptionLabel.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -12),
            descriptionLabel.bottomAnchor.constraint(lessThanOrEqualTo: cardView.bottomAnchor, constant: -12),

            playButton.centerYAnchor.constraint(equalTo: titleLabel.centerYAnchor),
            playButton.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -12),
            playButton.heightAnchor.constraint(equalToConstant: 30),
            playButton.widthAnchor.constraint(equalToConstant: 30)
        ])
    }

    func configure(with item: MorseHistoryViewController.HistoryItem) {
        itemImageView.image = item.imageName != nil ? UIImage(named: item.imageName!) : nil
        titleLabel.text = item.title
        descriptionLabel.text = item.description
        playButton.isHidden = item.morseCode == nil
    }

    @objc private func playTapped() {
        playButtonAction?()
    }
}
